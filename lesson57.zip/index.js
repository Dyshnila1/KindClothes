let a = prompt("Введите первую цифру", "");
let b = prompt("Введите вторую цифру", "");
alert(+a * +b);
